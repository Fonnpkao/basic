const http = require('http');
const express = require('express');
const app = express();
const mysql = require('mysql2');
const axios = require('axios');
const cors = require('cors');

app.use(cors());
app.use(express.json());

const port = 3001;

// เส้นทางแสดงข้อความ "Hello, World!"
app.get('/', (req, res) => {
  res.send('Hello, World!');
});

// เริ่มต้นการเชื่อมต่อฐานข้อมูล MySQL


// สร้าง connection pool
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: 'f@n1999',
  database: 'kpop',
  connectionLimit: 10, // จำนวนการเชื่อมต่อสูงสุดใน connection pool
});

// ใช้ connection pool เพื่อเรียกใช้งานฐานข้อมูล
pool.getConnection((error, connection) => {
  if (error) {
    console.error('เกิดข้อผิดพลาดในการเชื่อมต่อกับ MySQL:', error);
    return;
  }

  // ตัวอย่างคำสั่ง SQL
  const sql = 'SELECT * FROM member';

  // ใช้ connection เพื่อส่งคำสั่ง SQL
  connection.query(sql, (error, results) => {
    connection.release(); // คืน connection กลับเข้าสู่ connection pool

    if (error) {
      console.error('เกิดข้อผิดพลาดในการส่งคำสั่ง SQL:', error);
      return;
    }

    console.log('ผลลัพธ์:', results);
  });
});



// เริ่มต้นการเรียกใช้งานเซิร์ฟเวอร์
const server = http.createServer(app);

server.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
